#include "Pilha.h"
#include <stdio.h>
#include <stdlib.h>

//Opera��es
void Define(Pilha *P){
	P->topo = -1;
}
int Vazia(Pilha *P){
	return(P->topo==-1);
}
int Cheia(Pilha *P){
	return(P->topo == MAX-1);
}
int Push(Pilha *P, tipo_elem v){
	if(Cheia(P)){
		return 0;
	}
	
	P->topo++;
	P->A[P->topo] = v;
}

void PopUp(Pilha *P){
	if(Vazia(P)){
		return;
	}
	P->topo--;
} //Remover final


tipo_elem Pop(Pilha *P){
	tipo_elem v = P->A[P->topo];
	P->topo--;
	return (v);
}

tipo_elem Top(Pilha *P){
	return(P->A[P->topo]);
} 

void Esvaziar(Pilha *P){
	if(!Vazia(P)){
		P->topo = -1;
	}
}

void Exibir(Pilha *P){ //N�O FAZ PARTE desse tipo de TAD, usado somente para fins did�ticos
	int i;
	if(!Vazia(P)){
		for(i=0; i<P->topo; i++){
			printf("%d", P->A[i]);
		}
	}
}
