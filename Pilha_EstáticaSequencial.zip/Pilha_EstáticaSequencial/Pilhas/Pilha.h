#define MAX 10

//tipo de dado
typedef char tipo_elem;

//Estrutura de dados
typedef struct{
	tipo_elem A[MAX];
	char topo;
}Pilha;

//Opera��es
void Define(Pilha *P);
int Vazia(Pilha *P);
int Cheia(Pilha *P);
int Push(Pilha *P, tipo_elem v);//Inserir no inicio
void PopUp(Pilha *P); //Remover final
tipo_elem Pop(Pilha *P);
tipo_elem Top(Pilha *P); //Verificar o primeiro elemento
void Esvaziar(Pilha *P);
void Exibir(Pilha *P);//N�O FAZ PARTE desse tipo de TAD, usado somente para fins did�ticos
