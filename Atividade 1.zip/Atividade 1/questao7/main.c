#include <stdio.h>
#include <stdlib.h>

/* 7- Crie um programa que declare uma estrutura (registro) para o cadastro de alunos.  
a) Dever�o ser armazenados, para cada aluno: matr�cula, sobrenome (apenas um) e ano do  nascimento.  
b) Ao in�cio do programa, o usu�rio dever� informar o n�mero de alunos que ser�o  armazenados.  
c) O programa dever� alocar dinamicamente a quantidade necess�ria de mem�ria para  armazenar os registros dos alunos.  
d) O programa dever� pedir ao usu�rio que entre com as informa��es dos alunos.  
e) Ao final, mostrar os dados armazenados e liberar a mem�ria alocada.  */


typedef struct{
	int matricula;
	char sobrenome[50];
	int ano;
}registro;


int main(int argc, char *argv[]) {
	registro *a;
	int N, i; //numero de alunos
	
	printf("Bem vindo ao sistema de cadastro de alunos\n\n");
	printf("Digite o numero de alunos a serem cadastrados: ");
	scanf("%d", &N);
	
	//aloca��o din�mica, usando calloc ou malloc
	a = (registro *)malloc(N * sizeof(registro));
	
	if(a==NULL){
		printf("\nErro ao alocar mem�ria\n");
		return 1;
	}
	
	printf("\nEntre com as informacoes dos alunos\n");
	for(i=0; i<N; i++){
		printf("Aluno %d ", i+1);
		printf("Sobrenome do aluno: ");
		scanf("%s", &a[i].sobrenome);
		printf("Matricula: ");
		scanf("%d", &a[i].matricula);
		printf("Ano: ");
		scanf("%d", &a[i].ano);
	}
	
	printf("\nInformacoes dos alunos que foram fornecidas\n");
	for(i=0; i<N; i++){
		printf("Aluno %d, Sobrenome: %s, Matricula: %d, Ano: %d \n", i+1,
		a[i].sobrenome, a[i].matricula, a[i].ano);
	}
	
	free(a); //liberando a memoria
	
	system("pause");
	return 0;
}

