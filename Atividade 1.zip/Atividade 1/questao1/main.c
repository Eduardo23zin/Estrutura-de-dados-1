#include <stdio.h>
#include <stdlib.h>

/* 1- Escreva um programa que contenha duas vari�veis inteiras. Compare seus endere�os e exiba o  maior endere�o. */

int main(int argc, char *argv[]) {
	int a, b;
	
	printf("Ola usuario, esse eh um programa que compara os enderecos de duas variaveis do tipo inteiro e printa o maior endereco.\n\n");
	if(&a > &b){ // Se a for maior, printa a, sen�o, printa b
		printf("O endereco de a eh o maior: %p", &a);
	}else{
		printf("O endereco de b e o maior: %p", &b);
	}
	printf("\n\n");
	return 0;
	system("pause");
}
