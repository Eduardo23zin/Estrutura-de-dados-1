#include <stdio.h>
#include <stdlib.h>

/* 2.Crie um programa que contenha um array de float contendo 10 elementos. Imprima o endere�o de  cada posi��o desse array. */

int main(int argc, char *argv[]) {
	float vetor[10]; // declarando vetor
	int i; //variavel de posi��o
	
	printf("Seja bem vindo ao programa que mostra o endereco de cada posicao de um vetor!\n\n");
	for(i=0; i<10; i++){
		printf("Enderecos de %d no array: %p\n\n",i, &vetor[i]);
	}
	printf("\n\n");
	system("Pause");
	return 0;
}
