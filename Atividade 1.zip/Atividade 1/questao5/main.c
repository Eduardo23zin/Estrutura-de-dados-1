#include <stdio.h>
#include <stdlib.h>

/*5- Crie um programa que:  
(a) Aloque dinamicamente um array de 5 n�meros inteiros;  
(b) Pe�a para o usu�rio digitar os 5 n�meros no espa�o alocado;  
(c) Mostre na tela os 5 n�meros;  
(d) Libere a mem�ria alocada.   */

int main(int argc, char *argv[]) {
	int *array;
	int i;
	
	//aloca dinamicamente para 5 inteiros
	array = malloc(5 * sizeof(int));
	if(array==NULL){
		printf("Erro ao alocar memoria.\n");
		return 1;
	}
	
	printf("Bem vindo. Preciso que digite 5 numeros inteiros para que eu possa te mostrar o que voce digitou\n\n");
	
	for(i=0; i<5; i++){
		printf("Digite aqui o numero %d: ", i+1);
		scanf("%d", &array[i]);
	}
	printf("\n");
	
	
	printf("Printando numeros...\n");
	for(i=0; i<5;i++){
		printf("%d ", array[i]);
	}
	
	printf("\n\n");
	printf("Liberando memoria...\n");
	
	//Libera a mem�ria alocada
	free(array);
	
	system("pause");
	return 0;
}
