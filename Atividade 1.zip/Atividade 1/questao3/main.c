#include <stdio.h>
#include <stdlib.h>

/* 3.Crie um programa que contenha uma matriz de float contendo 3 linhas e 3 colunas. Imprima o  endere�o de cada posi��o dessa matriz.   */

int main(int argc, char *argv[]) {
	float matriz[3][3]; //declarando a matriz
	int i, j; // i = linha e j = coluna
	
	printf("Bem vindo ao programa que mostra o endereco de cada posicao de uma matriz!\n\n");
	printf("Imprimindo enderecos de cada posicao da matriz.\n\n");
	for(i=0; i<3; i++){ //percorre a linha
		for(j=0; j<3; j++){ //percorre a coluna
			printf("Endereco na linha %d e coluna %d: %p\n\n", i, j, &matriz[i][j]); //printando cada posi��o
		}
	}
	printf("\n\n");
	system("pause");
	return 0;
}
