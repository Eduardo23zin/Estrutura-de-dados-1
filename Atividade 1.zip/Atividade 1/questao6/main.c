#include <stdio.h>
#include <stdlib.h>

/* 6- Fa�a um programa que leia uma quantidade qualquer de n�meros armazenando-os na mem�ria e pare a leitura quando o usu�rio entrar com um n�mero negativo.
 Em seguida, imprima o vetor lido.  Use a fun��o REALLOC. */

int main() {
	int *numero=NULL;
	int i=0, j, valor;
	
	printf("Bem vindo. Por favor, Digite numeros inteiros. Se quiser sair, digite um valor negativo \n");
	
	printf("Digite os numeros aqui: ");
	while(1){
		scanf("%d", &valor);
		
		if(valor < 0) //para sair
		break;
		
		//realocando +1 de mem�ria a cada vez que o usu�rio digitar um novo valor
		int *temp = realloc(numero, (i+1) * sizeof(int));
		if(temp == NULL){
			printf("Erro ao alocar memoria.");
			free(numero); //libera o que ja tinha alocado
			return 1;
		}
		numero = temp; //aqui numero recebe o ponteiro temporario caso a realoca��o de mem�ria tenha ocorrido com sucesso, criei como medida
		              //de seguran�a, para n�o perder os valores digitados pelo usuario
		numero[i] = valor;
		i++;
	}
	
	printf("\nNumeros lidos...\n");
	
	if(i==0){
		printf("Nenhum valor foi digitado...\n"); // se o contador for 0, printa que nada foi digitado
	}else{
		for(j=0; j<i; j++){ //usei outra variavel para evitar problemas
		printf("%d ", numero[j]);
		}
	}
	printf("\n\n");

	free(numero);
	system("pause");
	return 0;
	
}
