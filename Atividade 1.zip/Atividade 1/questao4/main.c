#include <stdio.h>
#include <stdlib.h>

/* 4- Escreva um programa que imprima um vetor de inteiros na ordem inversa endere�ando os  elementos com um ponteiro. */

int main(int argc, char *argv[]) {
	int vetor[5] = {1, 2, 3, 4, 5}; // declarando vetor
	int i, *ponteiro = vetor + 4; //ponteiro apontando pra ultima posi��o do vetor
	
	printf("Ola usuario, esse programa imprime os elementos de um vetor na ordem inversa.\n\n");
	
	printf("imprimindo valores inversamente...\n");
	for(i=0; i<5; i++){
		printf("%d\n", *ponteiro); //printa os valores apontados
		ponteiro--; //faz o ponteiuro voltar pra posi��o anterior
	}
	
	printf("\n\n");
	system("pause");
	return 0;
}
