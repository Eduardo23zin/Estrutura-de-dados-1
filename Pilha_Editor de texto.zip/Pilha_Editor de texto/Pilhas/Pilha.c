#include "Pilha.h"
#include <stdio.h>
#include <stdlib.h>

//Opera��es
void Define(Pilha *P){
	P->topo=NULL;
}

int Vazia(Pilha *P){
	return(P->topo == NULL);
}

//int Cheia(Pilha *P){}
int Push(Pilha *P, tipo_elem v){
	No *aux = (No*)malloc(sizeof(No));
	
	if(!aux){
		return 0;
	}
	
	aux->info = v;
	aux->prox = P->topo;
	P->topo = aux;
}
void PopUp(Pilha *P){
	if(Vazia(P)){
		return;
	}
	
	No *aux = P->topo;
	P->topo = aux->prox;
	free(aux);
}


tipo_elem Pop(Pilha *P){
	tipo_elem v = (P->topo)->info;
	No *aux = P->topo;
	P->topo = aux->prox;
	free(aux);
	return v;
}

tipo_elem Top(Pilha *P){
	return(P->topo->info);
}


void Esvaziar(Pilha *P){
	No *k;
	while(P->topo != NULL){
		k=P->topo;
		P->topo = k->prox;
		free(k);
	}
}
//fazer em casa void Exibir(Pilha *P){}
