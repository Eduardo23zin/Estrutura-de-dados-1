#include <stdio.h>
#include <stdlib.h>
#include "Pilha.h"
#include <conio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	tipo_elem c;
	Pilha P;
	
	Define(&P);
	system("cls");
	
	do{ 
		printf("Bem vindo ao editor de texto!\n");
		printf("ENTER - para sair\n");
		printf("# - para apagar\n");
		printf("@ - para esvaziar\n");
		printf("\n\n");
		printf("Esccolha uma opcao: ");
	
		
		c = getch();
		switch(c){
			
			case 0x0d: //tecla ENTER
				printf("sair\n");
				break;
				
			case '#': //APAGA
				if(Vazia(&P)){
					printf("\nErro\n");
				}else{
					PopUp(&P);
				}
			break;
			
			case '@': //Esvazia a pilha
			Esvaziar(&P);
			break;
			
			
			default://tenta empilhar
				if(!Push(c, &P)){
					printf("Erro");
					break;
				}
		}	
		
	
	}while(c!=0x0d);
	return 0;
}
