#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int op;
	Lista L;
	tipo_elem v;
	int chave;
	
	
	Criar(&L);
	do{
		system("cls");
		printf("1- Inserir no final\n");
		printf("2- Exibir\n");
		printf("3- Destruir\n");
		printf("4- Verifica se a lista ta vazia\n");
		printf("5- Verifica se ta cheia\n");
		printf("6- Busca Binaria\n");
		printf("7- Remover no final\n");
		printf("8- Inserir ordenada\n");
		printf("0- Sair\n");
		
		printf("Digite a opcao\n");
		scanf("%d",&op);
		
		switch(op){
			case 1: //Inserir final
			printf("Digite o valor: ");
			scanf("%d", &v.chave);
			
			if(InserirFinal(&L, v))
			printf("Elemento inserido com sucesso \n");
			else
			printf("Nao foi possivel inserir \n");
			break;
			
			case 2: //Exibir
			Exibir(&L);
			break;
			
			case 3: //Destruir
			Destruir(&L);
			break;
			
			case 4: //Vazia
			if(Vazia(&L))
			printf("Vazia\n");
			else
			printf("Nao esta vazia\n");
			break;
			
			case 5: //Cheia
			if(Cheia(&L))
			printf("Lista cheia\n");
			else
			printf("Nao esta cheia\n");
			break;
			
			case 6:
				BuscaBinaria(&L, chave);
				break;
				
			case 7:
			RemoverFinal(&L);
			
		}
		system("pause");
	}while(op!=0);
	
	Destruir(&L);
	
	
	return 0;
}
